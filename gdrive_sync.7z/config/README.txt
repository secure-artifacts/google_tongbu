# 请将您的 Google Cloud OAuth 2.0 客户端密钥保存为此文件
# 
# 获取步骤：
# 1. 访问 https://console.cloud.google.com/
# 2. 创建或选择项目
# 3. 启用 Google Drive API
# 4. 创建 OAuth 2.0 客户端 ID（桌面应用）
# 5. 下载 JSON 文件并重命名为 credentials.json
# 6. 将文件放置在此目录下
